"""HIDDEN evaluator: compares each system's answers with the ground truth. Voltex never sees this."""
import random, collections
from world import EXPRESSIBLE_TRUE_RULES, DECOY_RULES

def rule_true_confidence(rule, T):
    """How often the rule's conclusion holds in the COMPLETE hidden world."""
    R = {p: set(map(tuple, v)) for p, v in T.items()}
    if any(r and r not in R for r in (rule["r1"], rule["r2"], rule["r3"])): return None
    n = k = 0
    if rule["type"] == "I":
        for a, b in R[rule["r1"]]:
            if a == b: continue
            n += 1; k += (b, a) in R[rule["r3"]]
    else:
        out = collections.defaultdict(set)
        for a, b in R[rule["r2"]]: out[a].add(b)
        for a, b in R[rule["r1"]]:
            for c in out[b]:
                if c == a: continue
                n += 1; k += (a, c) in R[rule["r3"]]
    return k / n if n else None

def key(rule): return (rule["type"], rule["r1"], rule["r2"] if rule["type"] != "I" else None, rule["r3"])

def evaluate(system_derived, observed, info, T, oracle_depth, preds, rules=None, conflicts=None, seed=0):
    truth = {(p, a, b) for p, fs in T.items() for a, b in map(tuple, fs)}
    obs = set(observed)
    unseen = set(info["unseen"]); sparse = set(info["sparse"])
    derived = set(system_derived) - obs
    heldout = {f for f in truth - obs if f[1] not in unseen and f[2] not in unseen}
    tp = derived & truth; fp = derived - truth
    r = {"derived": len(derived), "correct": len(tp), "wrong": len(fp),
         "precision": len(tp) / len(derived) if derived else None,
         "heldout": len(heldout), "recovered": len(derived & heldout), "recall": len(derived & heldout) / len(heldout)}
    reach = {f for f in heldout if f in oracle_depth}
    r["derivable_heldout"] = len(reach)
    r["recall_on_derivable"] = len(derived & reach) / len(reach) if reach else None
    # per depth (depth = steps the true-rule oracle needs from the observations)
    byd = collections.defaultdict(lambda: [0, 0])
    for f in heldout:
        d = oracle_depth.get(f); b = "not derivable" if d is None else (str(d) if d < 4 else "4+")
        byd[b][0] += 1; byd[b][1] += f in derived
    r["recall_by_depth"] = {k: {"heldout": v[0], "recovered": v[1], "recall": v[1] / v[0]} for k, v in sorted(byd.items())}
    # per predicate
    pp = {}
    for p in preds:
        h = {f for f in heldout if f[0] == p}; d = {f for f in derived if f[0] == p}
        pp[p] = {"heldout": len(h), "recovered": len(d & h), "derived": len(d), "wrong": len(d - truth)}
    r["per_predicate"] = pp
    # balanced question set -> false positive / false negative rates
    rng = random.Random(seed + 99)
    objs = collections.defaultdict(set)
    for p, a, b in truth: objs[p].add(b)
    answers = obs | derived
    yes_t = n_t = yes_f = n_f = 0
    for p in preds:
        hs = sorted(f for f in heldout if f[0] == p)
        for f in rng.sample(hs, min(50, len(hs))):
            n_t += 1; yes_t += f in answers
            pool = sorted(objs[p] - {f[2]})
            for _ in range(20):
                c = rng.choice(pool) if pool else None
                if c and (p, f[1], c) not in truth: n_f += 1; yes_f += (p, f[1], c) in answers; break
    r["questions"] = {"true_q": n_t, "false_q": n_f, "FNR": 1 - yes_t / n_t if n_t else None, "FPR": yes_f / n_f if n_f else None,
                      "accuracy": (yes_t + (n_f - yes_f)) / (n_t + n_f) if n_t + n_f else None}
    # generalisation to entities with almost nothing ingested (sparse) and to entities never ingested (unseen)
    hs = {f for f in heldout if f[1] in sparse}
    ds = {f for f in derived if f[1] in sparse}
    r["sparse_entities"] = {"heldout": len(hs), "recovered": len(ds & hs), "derived": len(ds), "wrong": len(ds - truth)}
    r["unseen_entities"] = {"facts_about_them_derived": sum(1 for f in derived if f[1] in unseen or f[2] in unseen)}
    if rules is not None:
        acc = [x for x in rules if x["accepted"]]
        for x in acc:
            x["true_conf"] = rule_true_confidence(x, T)
            x["designed_true"] = key(x) in {(a, b, c, d) for a, b, c, d in EXPRESSIBLE_TRUE_RULES}
            x["designed_decoy"] = key(x) in {(a, b, c, d) for a, b, c, d in DECOY_RULES}
        valid = [x for x in acc if x["true_conf"] is not None and x["true_conf"] >= 0.9]
        r["rules"] = {"accepted": len(acc), "valid(true_conf>=0.9)": len(valid),
                      "rule_precision": len(valid) / len(acc) if acc else None,
                      "designed_true_found": sorted({str(key(x)) for x in acc if x["designed_true"]}),
                      "designed_true_total": len(EXPRESSIBLE_TRUE_RULES),
                      "decoys_accepted": sorted({str(key(x)) for x in acc if x["designed_decoy"]}),
                      "list": acc}
    if conflicts is not None:
        bad = {(w[1], w[2]) for w in info["wrong"]}
        flagged = {(c[0], c[1]) for c in conflicts}
        hit = flagged & bad
        r["contradictions"] = {"injected": len(bad), "flagged": len(flagged), "correct_flags": len(hit),
                               "detection_recall": len(hit) / len(bad) if bad else None,
                               "flag_precision": len(hit) / len(flagged) if flagged else None}
    return r
